import 'package:coursein/market_detail_page.dart';
import 'package:coursein/models/course.dart';
import 'package:flutter/material.dart';

class Market extends StatefulWidget {
  const Market({super.key});

  @override
  State<Market> createState() => _MarketState();
}

class _MarketState extends State<Market> {
  final List<Course> allCourses = [
    Course(
      id: "1",
      title: "Market Stock",
      instructor: "John Doe",
      imageUrl:
          "https://5.imimg.com/data5/ANDROID/Default/2023/9/346681705/VR/GM/KO/121520095/product-jpeg.jpg",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "2",
      title: "Share Market",
      instructor: "Jane Smith",
      imageUrl:
          "https://d502jbuhuh9wk.cloudfront.net/courses/652f8559e4b017eea3620063/qmpJJwhatsappimage20231018at7.35.01pm.jpg",
      rating: 4.8,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "3",
      title: "Stock Market Class",
      instructor: "John Doe",
      imageUrl:
          "https://static.wixstatic.com/media/8df4df_a754a325477546adaa8e19a16420bb65~mv2.jpeg/v1/fill/w_2500,h_2500,al_c/8df4df_a754a325477546adaa8e19a16420bb65~mv2.jpeg",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "4",
      title: "Online Market",
      instructor: "John Doe",
      imageUrl:
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0G6YNymltIsqpH5Ev5HAqooDdPzizUeTAvw&s",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "5",
      title: "Digital Marketing",
      instructor: "John Doe",
      imageUrl:
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQKPqdYHh6vUIJGDtvQOH320aVHVV28f7GeUQ&s",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "6",
      title: "Janseva Center",
      instructor: "John Doe",
      imageUrl: "https://trbahadurpur.in/wp-content/uploads/2023/05/image.png",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
  ];

  List<Course> filteredCourses = [];

  @override
  void initState() {
    super.initState();
    filteredCourses = allCourses;
  }

  void _filterCourses(String query) {
    setState(() {
      filteredCourses =
          allCourses
              .where(
                (course) =>
                    course.title.toLowerCase().contains(query.toLowerCase()),
              )
              .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Market", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.orange,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Search Bar
            TextField(
              decoration: InputDecoration(
                hintText: "Search courses...",
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onChanged: _filterCourses,
            ),
            const SizedBox(height: 16),

            // Grid of Courses
            Expanded(
              child: GridView.builder(
                itemCount: filteredCourses.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 3 / 4,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemBuilder: (context, index) {
                  final course = filteredCourses[index];
                  final relatedCourses =
                      allCourses.where((c) => c != course).take(6).toList();
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder:
                              (_) => MarketDetailPage(
                                course: course,
                                relatedCourses: relatedCourses,
                              ),
                        ),
                      );
                    },
                    child: CourseCard(course: course),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Course Card Widget
class CourseCard extends StatelessWidget {
  final Course course;

  const CourseCard({super.key, required this.course});

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Course image
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            child: Image.network(
              course.imageUrl,
              height: 100,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              course.title,
              style: const TextStyle(fontWeight: FontWeight.bold),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              course.instructor,
              style: const TextStyle(color: Colors.grey),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                const Icon(Icons.star, color: Colors.orange, size: 16),
                const SizedBox(width: 4),
                Text(course.rating.toString()),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              course.price,
              style: const TextStyle(color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }
}
