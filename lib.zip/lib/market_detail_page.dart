import 'package:coursein/razorpaygetway.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:coursein/models/course.dart';

class MarketDetailPage extends StatefulWidget {
  final Course course;
  final List<Course> relatedCourses;

  const MarketDetailPage({
    super.key,
    required this.course,
    required this.relatedCourses,
  });

  @override
  State<MarketDetailPage> createState() => _MarketDetailPageState();
}

class _MarketDetailPageState extends State<MarketDetailPage> {
  late Course _currentCourse;
  late VideoPlayerController _controller;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    _currentCourse = widget.course;
    _loadVideo(_currentCourse.previewVideoUrl);
  }

  void _loadVideo(String url) {
    try {
      _controller.dispose();
    } catch (_) {}

    _controller =
        url.startsWith('http')
            ? VideoPlayerController.network(url)
            : VideoPlayerController.asset(url);

    _controller
        .initialize()
        .then((_) {
          setState(() => _isVideoInitialized = true);
        })
        .catchError((error) {
          debugPrint("Error initializing video: $error");
        });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final course = _currentCourse;

    return Scaffold(
      appBar: AppBar(title: Text(course.title)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(course.imageUrl),
            const SizedBox(height: 16),

            Text(
              course.title,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),

            Text(
              "Instructor: ${course.instructor}",
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 8),

            Row(
              children: [
                const Icon(Icons.star, color: Colors.orange),
                const SizedBox(width: 4),
                Text(
                  course.rating.toString(),
                  style: const TextStyle(fontSize: 16),
                ),
              ],
            ),
            const SizedBox(height: 16),

            const Text(
              "Course Details",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              "Course details go here. You can add more description, videos, lessons, and content as needed.",
              style: TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 24),

            const Text(
              "Course Preview",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            AspectRatio(
              aspectRatio: 16 / 9,
              child:
                  _isVideoInitialized
                      ? Stack(
                        alignment: Alignment.bottomCenter,
                        children: [
                          VideoPlayer(_controller),
                          VideoProgressIndicator(
                            _controller,
                            allowScrubbing: true,
                          ),
                          Center(
                            child: IconButton(
                              icon: Icon(
                                _controller.value.isPlaying
                                    ? Icons.pause_circle_filled
                                    : Icons.play_circle_fill,
                                size: 64,
                                color: Colors.white,
                              ),
                              onPressed: () {
                                setState(() {
                                  _controller.value.isPlaying
                                      ? _controller.pause()
                                      : _controller.play();
                                });
                              },
                            ),
                          ),
                        ],
                      )
                      : const Center(child: CircularProgressIndicator()),
            ),
            const SizedBox(height: 24),

            const Text(
              "Related Courses",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children:
                    widget.relatedCourses
                        .where((related) => related.id != _currentCourse.id)
                        .map((relatedCourse) {
                          return GestureDetector(
                            onTap: () {
                              setState(() {
                                _isVideoInitialized = false;
                                _currentCourse = relatedCourse;
                                _loadVideo(_currentCourse.previewVideoUrl);
                              });
                            },
                            child: Container(
                              width: 160,
                              color: Colors.grey[200],
                              margin: const EdgeInsets.only(right: 12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Image.network(
                                    relatedCourse.imageUrl,
                                    fit: BoxFit.cover,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          relatedCourse.title,
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        Text(
                                          "Instructor: ${relatedCourse.instructor}",
                                          style: const TextStyle(fontSize: 12),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        })
                        .toList(),
              ),
            ),
            const SizedBox(height: 24),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Buy this course",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text("₹499 for lifetime access"),
                  const SizedBox(height: 12),
                  Center(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (context) => RazorpayCheckoutPage(
                                  course: _currentCourse,
                                ),
                          ),
                        );
                      },
                      child: const Text("Buy Now"),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
