import 'package:coursein/models/videoplayer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final List<Map<String, String>> allCourses = [
    {"title": "Adobe Photoshop Class", "duration": "7 hrs, 12 mins"},
    {"title": "Adobe Illustrator Class", "duration": "7 hrs, 12 mins"},
    {"title": "Adobe CorelDraw Class", "duration": "7 hrs, 12 mins"},
    {"title": "Graphics Designer Class", "duration": "6 hrs, 20 mins"},
    {"title": "Web Designer Class", "duration": "9 hrs, 35 mins"},
  ];

  List<Map<String, String>> filteredCourses = [];

  @override
  void initState() {
    super.initState();
    filteredCourses = allCourses;
  }

  void _filterCourses(String query) {
    setState(() {
      filteredCourses =
          allCourses
              .where(
                (course) => course['title']!.toLowerCase().contains(
                  query.toLowerCase(),
                ),
              )
              .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final User? user = FirebaseAuth.instance.currentUser;
    final String email = user?.email ?? 'Guest';

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.grey[100],
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.red),
            onPressed: () {
              Navigator.pushReplacementNamed(context, '/');
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text.rich(
              TextSpan(
                text: 'Hello ',
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
                children: [
                  TextSpan(
                    text: email,
                    style: const TextStyle(color: Colors.blue, fontSize: 20),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            const Text("What do you want to learn?"),
            const SizedBox(height: 20),
            TextFormField(
              decoration: InputDecoration(
                hintText: 'Search...',
                prefixIcon: const Icon(Icons.search, color: Colors.grey),
                filled: true,
                fillColor: Colors.grey[300],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: _filterCourses,
            ),
            const SizedBox(height: 20),
            Container(
              height: 120,
              decoration: BoxDecoration(
                color: Colors.blue[300],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text.rich(
                          TextSpan(
                            children: [
                              TextSpan(
                                text: "New Course\n",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                  fontSize: 20,
                                ),
                              ),
                              TextSpan(
                                text: "UI Design - Mobile App",
                                style: TextStyle(
                                  fontWeight: FontWeight.normal,
                                  color: Colors.white,
                                  fontSize: 18,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        OutlinedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder:
                                    (context) => const VideoPlayerPage(
                                      videoUrl: 'assets/flutter_ads.mp4',
                                    ),
                              ),
                            );
                          },
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Colors.white),
                            backgroundColor: Colors.blueGrey[200],
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 5,
                              vertical: 0,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          child: const Text(
                            'See Class',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Courses",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            const SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  CategoryButton(label: 'All', color: Colors.blue),
                  CategoryButton(label: 'Design', color: Colors.grey),
                  CategoryButton(label: 'Photography', color: Colors.purple),
                  CategoryButton(label: 'Market', color: Colors.orange),
                ],
              ),
            ),
            const SizedBox(height: 20),
            ...filteredCourses.map(
              (course) => CourseTile(
                title: course['title']!,
                duration: course['duration']!,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder:
                          (_) => const VideoPlayerPage(
                            videoUrl: 'assets/flutter_ads.mp4',
                          ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CourseTile extends StatelessWidget {
  final String title, duration;
  final VoidCallback? onTap;
  const CourseTile({
    super.key,
    required this.title,
    required this.duration,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        onTap: onTap,
        leading: const Icon(Icons.person),
        title: Text(title),
        subtitle: Text(duration),
        trailing: const Icon(Icons.star, color: Colors.yellow),
      ),
    );
  }
}

class CategoryButton extends StatelessWidget {
  final String label;
  final Color color;
  const CategoryButton({super.key, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8.0),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
        ),
        onPressed: () {
          switch (label.toLowerCase()) {
            case 'all':
              Navigator.pushNamed(context, '/mainlayout');
              break;
            case 'design':
              Navigator.pushNamed(context, '/coursepage');
              break;
            case 'photography':
              Navigator.pushNamed(context, '/photographypage');
              break;
            case 'market':
              Navigator.pushNamed(context, '/marketpage');
              break;
          }
        },
        child: Text(label, style: const TextStyle(color: Colors.white)),
      ),
    );
  }
}
