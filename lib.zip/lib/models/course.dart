// Course Data Models
class Course {
  final String id; // 👈 Add this line
  final String title;
  final String instructor;
  final String imageUrl;
  final double rating;
  final String price;
  final String previewVideoUrl; // ✅ Add this

  Course({
    required this.id, // 👈 Add in constructor
    required this.title,
    required this.instructor,
    required this.imageUrl,
    required this.rating,
    required this.price,
    required this.previewVideoUrl, // ✅ Add this
  });
}
