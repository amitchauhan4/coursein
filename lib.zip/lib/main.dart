import 'package:coursein/allcategorycourse.dart';
import 'package:coursein/design.dart';
import 'package:coursein/logindashboard.dart';
import 'package:coursein/logindashboardscreen.dart';
import 'package:coursein/loginseconddashboard.dart';
import 'package:coursein/market.dart';
import 'package:coursein/photography.dart';
import 'package:coursein/signupdashboardscreen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

/// Simple user data storage (in-memory)
class UserStore {
  static final Map<String, String> _users = {};

  static bool register(String email, String password) {
    if (_users.containsKey(email)) return false;
    _users[email] = password;
    return true;
  }

  static bool login(String email, String password) {
    return _users[email] == password;
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'CourseIn',
      initialRoute: '/',
      routes: {
        '/': (context) => const SignInPage(),
        '/login': (context) => const LoginPage(),
        '/signup': (context) => const SignupPage(),
        '/dashboard': (context) => const DashboardPage(),
        '/coursepage': (context) => const CoursePage(),
        '/photographypage': (context) => const Photography(),
        '/marketpage': (context) => const Market(),
        '/mainlayout': (context) => const MainLayout(),
      },
    );
  }
}
