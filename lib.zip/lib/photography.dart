import 'package:coursein/photography_detail_page.dart';
import 'package:coursein/models/course.dart';
import 'package:flutter/material.dart';

class Photography extends StatefulWidget {
  const Photography({super.key});

  @override
  State<Photography> createState() => _PhotographyState();
}

class _PhotographyState extends State<Photography> {
  final List<Course> allCourses = [
    Course(
      id: "1",
      title: "Basic Photography",
      instructor: "John Doe",
      imageUrl: "https://i.ytimg.com/vi/ujaCbzLwuB8/sddefault.jpg",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "2",
      title: "Analog Photography",
      instructor: "Jane Smith",
      imageUrl:
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRFksiJVFG5HG-pnpcwKnmiY5TMYNYXxAqyBw&s",
      rating: 4.8,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "3",
      title: "Short Photography",
      instructor: "John Doe",
      imageUrl:
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYbsJFulTRg3kb36fs2oHH0rDX5C0uJ6HBDQ&s",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "4",
      title: "Workshop Photography",
      instructor: "John Doe",
      imageUrl:
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTNj9sGIo6-gyt8CwwFiJ9oCCv_CADVZM9xMA&s",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "5",
      title: "Digital Photography",
      instructor: "John Doe",
      imageUrl:
          "https://images.shiksha.com/mediadata/images/articles/1568193656phpmWI2xq.jpeg",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "6",
      title: "Food Photography",
      instructor: "John Doe",
      imageUrl:
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2cd5rmKrztwK-o-ovA7LunBTpFhla6daKDQ&s",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
  ];

  List<Course> filteredCourses = [];

  @override
  void initState() {
    super.initState();
    filteredCourses = allCourses;
  }

  void _filterCourses(String query) {
    setState(() {
      filteredCourses =
          allCourses
              .where(
                (course) =>
                    course.title.toLowerCase().contains(query.toLowerCase()),
              )
              .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Photography", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.purple,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Search Bar
            TextField(
              decoration: InputDecoration(
                hintText: "Search courses...",
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onChanged: _filterCourses,
            ),
            const SizedBox(height: 16),

            // Grid of Courses
            Expanded(
              child: GridView.builder(
                itemCount: filteredCourses.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 3 / 4,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemBuilder: (context, index) {
                  final course = filteredCourses[index];
                  final relatedCourses =
                      allCourses.where((c) => c != course).take(6).toList();
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder:
                              (context) => PhotographyDetailPage(
                                course: course,
                                relatedCourses: relatedCourses,
                              ),
                        ),
                      );
                    },
                    child: CourseCard(course: course),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Course Card Widget
class CourseCard extends StatelessWidget {
  final Course course;

  const CourseCard({super.key, required this.course});

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Course image
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            child: Image.network(
              course.imageUrl,
              height: 100,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              course.title,
              style: const TextStyle(fontWeight: FontWeight.bold),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              course.instructor,
              style: const TextStyle(color: Colors.grey),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                const Icon(Icons.star, color: Colors.orange, size: 16),
                const SizedBox(width: 4),
                Text(course.rating.toString()),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              course.price,
              style: const TextStyle(color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }
}
