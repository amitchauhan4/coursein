import 'package:coursein/course_detail_page.dart';
import 'package:coursein/models/course.dart';
import 'package:flutter/material.dart';

class CoursePage extends StatefulWidget {
  const CoursePage({super.key});

  @override
  State<CoursePage> createState() => _CoursePageState();
}

class _CoursePageState extends State<CoursePage> {
  final List<Course> allCourses = [
    Course(
      id: "1",
      title: "Flutter Development",
      instructor: "John Doe",
      imageUrl:
          "https://cdn.shopaccino.com/igmguru/products/flutter-igmguru_1527424732_xl.jpg?v=532",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "2",
      title: "UI/UX Design",
      instructor: "Jane Smith",
      imageUrl:
          "https://bmuemergingtech.com/wp-content/uploads/2024/02/ui-ux.jpg",
      rating: 4.8,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "3",
      title: "Python Development",
      instructor: "John Doe",
      imageUrl:
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYbsJFulTRg3kb36fs2oHH0rDX5C0uJ6HBDQ&s",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "4",
      title: "Android Development",
      instructor: "John Doe",
      imageUrl:
          "https://www.besanttechnologies.com/wp-content/uploads/2021/10/android-training-institute-in-chennai.webp",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "5",
      title: "Java Full Stack",
      instructor: "John Doe",
      imageUrl:
          "https://t3.ftcdn.net/jpg/04/51/12/88/360_F_451128839_vmKOyil368UoXcac46W7aaqelTtLuNFk.jpg",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
    Course(
      id: "6",
      title: "Dot Net Development",
      instructor: "John Doe",
      imageUrl:
          "https://www.keenesystems.com/hubfs/Landing%20Page/ASP_NET-Software-Development-Outsourcing.jpg",
      rating: 4.5,
      price: "Best price: ₹499",
      previewVideoUrl: 'assets/flutter_ads.mp4',
    ),
  ];

  List<Course> filteredCourses = [];

  @override
  void initState() {
    super.initState();
    filteredCourses = allCourses;
  }

  void _filterCourses(String query) {
    setState(() {
      filteredCourses =
          allCourses
              .where(
                (course) =>
                    course.title.toLowerCase().contains(query.toLowerCase()),
              )
              .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Design", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.grey,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Search Bar
            TextField(
              decoration: InputDecoration(
                hintText: "Search courses...",
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onChanged: _filterCourses,
            ),
            const SizedBox(height: 16),

            // Grid of Courses
            Expanded(
              child: GridView.builder(
                itemCount: filteredCourses.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 3 / 4,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemBuilder: (context, index) {
                  final course = filteredCourses[index];
                  final relatedCourses =
                      allCourses.where((c) => c != course).take(6).toList();
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder:
                              (context) => CourseDetailPage(
                                course: course,
                                relatedCourses: relatedCourses,
                              ),
                        ),
                      );
                    },
                    child: CourseCard(course: course),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Course Card Widget
class CourseCard extends StatelessWidget {
  final Course course;

  const CourseCard({super.key, required this.course});

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Course image
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            child: Image.network(
              course.imageUrl,
              height: 100,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              course.title,
              style: const TextStyle(fontWeight: FontWeight.bold),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              course.instructor,
              style: const TextStyle(color: Colors.grey),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                const Icon(Icons.star, color: Colors.orange, size: 16),
                const SizedBox(width: 4),
                Text(course.rating.toString()),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              course.price,
              style: const TextStyle(color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }
}
